"use client";

import { useEffect, useState } from "react";

type VoiceState = "idle" | "request" | "generated" | "decoded" | "playing" | "error";

function friendlyVoiceError(detail: string, status: number) {
  if (detail === "openai_api_key_missing") return "Voz · falta OPENAI_API_KEY en Vercel";
  if (detail === "openai_api_key_invalid_format") return "Voz · OPENAI_API_KEY no contiene una clave de OpenAI";
  if (detail === "openai_api_key_rejected") return "Voz · OpenAI ha rechazado OPENAI_API_KEY";
  if (detail === "openai_quota_exhausted") return "Voz · la cuenta API de OpenAI no tiene cuota/crédito disponible";
  if (detail === "openai_rate_limited") return "Voz · OpenAI mantiene limitado el audio y el respaldo del iPhone no ha arrancado";
  if (detail === "openai_service_unavailable") return "Voz · servicio de OpenAI no disponible ahora";
  return `Voz · TTS ${status}${detail ? ` · ${detail}` : ""}`;
}

function speechTextFromRequest(init?: RequestInit) {
  if (typeof init?.body !== "string") return "";
  try {
    const body = JSON.parse(init.body) as { text?: string };
    return typeof body.text === "string" ? body.text.trim() : "";
  } catch {
    return "";
  }
}

function chooseDeviceVoice() {
  const voices = window.speechSynthesis?.getVoices?.() ?? [];
  const spanish = voices.filter((voice) => voice.lang.toLowerCase().startsWith("es"));
  return spanish.find((voice) => voice.lang.toLowerCase() === "es-es")
    || spanish.find((voice) => /m[oó]nica|marta|helena|paulina|female|mujer/i.test(voice.name))
    || spanish[0];
}

function primeDeviceSpeech() {
  if (!("speechSynthesis" in window)) return;
  try {
    const synth = window.speechSynthesis;
    const utterance = new SpeechSynthesisUtterance(" ");
    utterance.lang = "es-ES";
    utterance.volume = 0.01;
    utterance.rate = 2;
    utterance.voice = chooseDeviceVoice() || null;
    synth.cancel();
    synth.resume();
    synth.speak(utterance);
  } catch {
    // Priming is best effort only.
  }
}

function speakWithDevice(text: string, signal?: AbortSignal | null) {
  return new Promise<boolean>((resolve) => {
    if (!text || !("speechSynthesis" in window)) {
      resolve(false);
      return;
    }

    const synth = window.speechSynthesis;
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "es-ES";
    utterance.rate = 0.98;
    utterance.pitch = 0.92;
    utterance.volume = 1;
    utterance.voice = chooseDeviceVoice() || null;

    let settled = false;
    let started = false;
    const finish = (ok: boolean) => {
      if (settled) return;
      settled = true;
      signal?.removeEventListener("abort", onAbort);
      window.clearTimeout(startTimer);
      window.clearTimeout(endTimer);
      resolve(ok);
    };
    const onAbort = () => {
      synth.cancel();
      finish(false);
    };
    const startTimer = window.setTimeout(() => {
      if (!started) {
        try {
          synth.cancel();
          synth.resume();
          synth.speak(utterance);
        } catch {
          finish(false);
        }
      }
    }, 700);
    const endTimer = window.setTimeout(() => {
      synth.cancel();
      finish(false);
    }, Math.max(10_000, Math.min(40_000, text.length * 80)));

    utterance.onstart = () => {
      started = true;
    };
    utterance.onend = () => finish(true);
    utterance.onerror = () => finish(false);
    signal?.addEventListener("abort", onAbort, { once: true });

    try {
      synth.cancel();
      synth.resume();
      window.setTimeout(() => {
        try {
          synth.speak(utterance);
        } catch {
          finish(false);
        }
      }, 120);
    } catch {
      finish(false);
    }
  });
}

export default function VoiceBridge() {
  const [state, setState] = useState<VoiceState>("idle");
  const [detail, setDetail] = useState("");

  useEffect(() => {
    let active = true;
    let ttsWindowUntil = 0;
    let hideTimer: number | null = null;

    const update = (next: VoiceState, text: string, keep = false) => {
      if (!active) return;
      setState(next);
      setDetail(text);
      if (hideTimer) window.clearTimeout(hideTimer);
      if (!keep && next !== "error") {
        hideTimer = window.setTimeout(() => {
          if (!active) return;
          setState("idle");
          setDetail("");
        }, 12_000);
      }
    };

    const prime = () => primeDeviceSpeech();
    window.addEventListener("pointerdown", prime, { passive: true });
    window.addEventListener("touchstart", prime, { passive: true });

    const originalFetch = window.fetch.bind(window);
    window.fetch = (async (input: RequestInfo | URL, init?: RequestInit) => {
      const url = typeof input === "string"
        ? input
        : input instanceof URL
          ? input.toString()
          : input.url;
      const isVoice = url.includes("/api/voice/speech");
      if (!isVoice) return originalFetch(input, init);

      update("request", "Voz · generando audio…", true);
      try {
        const response = await originalFetch(input, init);
        if (!response.ok) {
          let reason = "";
          try {
            const payload = await response.clone().json() as { detail?: string; error?: string };
            reason = payload.detail || payload.error || "";
          } catch {
            reason = "";
          }

          const fallbackText = speechTextFromRequest(init);
          if (fallbackText && reason !== "openai_api_key_missing" && reason !== "openai_api_key_invalid_format") {
            update("playing", "Voz · probando respaldo del iPhone…", true);
            const played = await speakWithDevice(fallbackText, init?.signal);
            if (played) {
              update("playing", "Voz · respuesta reproducida con la voz del iPhone", false);
              return response;
            }
          }

          update("error", friendlyVoiceError(reason, response.status), true);
          return response;
        }

        const clone = response.clone();
        const bytes = await clone.arrayBuffer().catch(() => new ArrayBuffer(0));
        const model = response.headers.get("X-Zyron-Voice-Model") || "OpenAI TTS";
        ttsWindowUntil = Date.now() + 15_000;
        const kb = bytes.byteLength ? Math.max(1, Math.round(bytes.byteLength / 1024)) : 0;
        update("generated", `Voz · audio generado · ${model}${kb ? ` · ${kb} KB` : ""}`, true);
        return response;
      } catch (error) {
        const reason = error instanceof Error ? error.message : "fallo de red";
        update("error", `Voz · error de red · ${reason.slice(0, 120)}`, true);
        throw error;
      }
    }) as typeof window.fetch;

    const AudioContextCtor = window.AudioContext;
    const contextPrototype = AudioContextCtor?.prototype;
    const sourcePrototype = typeof AudioBufferSourceNode !== "undefined" ? AudioBufferSourceNode.prototype : null;
    const originalDecode = contextPrototype?.decodeAudioData;
    const originalStart = sourcePrototype?.start;

    if (contextPrototype && originalDecode) {
      try {
        contextPrototype.decodeAudioData = (function (this: AudioContext, audioData: ArrayBuffer, successCallback?: DecodeSuccessCallback | null, errorCallback?: DecodeErrorCallback | null) {
          const promise = originalDecode.call(this, audioData);
          void promise.then((buffer) => {
            if (Date.now() < ttsWindowUntil) update("decoded", `Voz · audio preparado · ${buffer.duration.toFixed(1)} s`, true);
            successCallback?.(buffer);
          }).catch((error) => {
            if (Date.now() < ttsWindowUntil) update("error", `Voz · no se puede decodificar el audio · ${error instanceof Error ? error.message : "error"}`, true);
            errorCallback?.(error as DOMException);
          });
          return promise;
        }) as typeof contextPrototype.decodeAudioData;
      } catch {
        // Diagnostics are optional and must never break voice playback.
      }
    }

    if (sourcePrototype && originalStart) {
      try {
        sourcePrototype.start = (function (this: AudioBufferSourceNode, when?: number, offset?: number, duration?: number) {
          if (Date.now() < ttsWindowUntil) update("playing", "Voz · reproduciendo en el iPhone", false);
          return originalStart.call(this, when, offset, duration);
        }) as typeof sourcePrototype.start;
      } catch {
        // Diagnostics are optional and must never break voice playback.
      }
    }

    return () => {
      active = false;
      if (hideTimer) window.clearTimeout(hideTimer);
      window.removeEventListener("pointerdown", prime);
      window.removeEventListener("touchstart", prime);
      window.fetch = originalFetch;
      window.speechSynthesis?.cancel();
      try {
        if (contextPrototype && originalDecode) contextPrototype.decodeAudioData = originalDecode;
        if (sourcePrototype && originalStart) sourcePrototype.start = originalStart;
      } catch {
        // Browser prototypes can be read-only.
      }
    };
  }, []);

  if (state === "idle") return null;

  return (
    <div
      role="status"
      aria-live="polite"
      style={{
        position: "fixed",
        left: "50%",
        bottom: "14px",
        transform: "translateX(-50%)",
        zIndex: 9999,
        maxWidth: "calc(100vw - 28px)",
        padding: "9px 13px",
        borderRadius: "999px",
        background: state === "error" ? "rgba(90,20,32,.96)" : "rgba(8,18,46,.96)",
        border: "1px solid rgba(124,159,255,.45)",
        color: "#f7f9ff",
        fontSize: ".78rem",
        boxShadow: "0 8px 26px rgba(0,0,0,.28)",
        textAlign: "center",
      }}
    >
      {detail}
    </div>
  );
}
